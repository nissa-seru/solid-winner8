package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI.EngineSpecAPI;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.MissileSpecAPI;
import com.fs.starfarer.api.loading.ProjectileSpecAPI;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.ArrayList;
import org.lwjgl.input.Keyboard;

public class TMI_Wings extends BaseHullMod {
    private int presses = 0;
    private int presses2 = 0;

    public void addPostDescriptionSection(TooltipMakerAPI tooltip, ShipAPI.HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
        float opad = 10f;
        if (ship == null) {return;}
        tooltip.setBulletedListMode(null);
        if (presses >= ship.getVariant().getWings().size()) {presses = 0;presses2 = 0;}
        if (Keyboard.isKeyDown(Keyboard.getKeyIndex("F1"))) {
            if (presses2 <= 1 || presses2-1 < Global.getSettings().getFighterWingSpec((String) ship.getVariant().getWings().get(presses)).getVariant().getFittedWeaponSlots().size()) presses2++; else {presses2=0;}
        }
        
        if (Keyboard.isKeyDown(Keyboard.getKeyIndex("F3"))) {
            presses++;presses2=0;if (presses >= ship.getVariant().getWings().size()) {presses = 0;}
        }
        if (Keyboard.isKeyDown(Keyboard.getKeyIndex("F2"))) {
            presses--;presses2=0;if (presses < 0) {presses = !ship.getVariant().getWings().isEmpty() ? ship.getVariant().getWings().size()-1 : 0;}
        }
        tooltip.setBulletedListMode(null);
        if (!ship.getVariant().getWings().isEmpty() && presses < ship.getVariant().getWings().size() && Global.getSettings().getFighterWingSpec((String) ship.getVariant().getWings().get(presses)) != null) {
            FighterWingSpecAPI wingspec = (FighterWingSpecAPI) Global.getSettings().getFighterWingSpec((String) ship.getVariant().getWings().get(presses));
            ShipHullSpecAPI hullspec = wingspec.getVariant().getHullSpec();//ShipHullSpecAPI hullspec = Global.getSettings().getHullSpec(wingspec.getId().substring(0, wingspec.getId().length()-5));
            if (presses2 == 0 && hullspec != null) {
                tooltip.addSectionHeading(hullspec.getHullName(), Alignment.MID, opad);
                tooltip.beginTable(Misc.getBasePlayerColor(), Misc.getDarkPlayerColor(), Misc.getBrightPlayerColor(), 15f, Global.getSettings().getString("timid_tmi", "stat"), 220f, Global.getSettings().getString("timid_tmi", "value"), 50f, Global.getSettings().getString("timid_tmi", "change"), 80f);
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "topspeed"), "", hullspec.getEngineSpec().getMaxSpeed());
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "acceleration"), "", hullspec.getEngineSpec().getAcceleration());
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "deceleration"), "", hullspec.getEngineSpec().getDeceleration());
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "turnrate"), "", hullspec.getEngineSpec().getMaxTurnRate());
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "turnacceleration"), "", hullspec.getEngineSpec().getTurnAcceleration());
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "basereplacementtime"), wingspec.getRefitTime()*ship.getMutableStats().getFighterRefitTimeMult().getModifiedValue(), wingspec.getRefitTime(), false);
                if (wingspec.getAttackRunRange() != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "attackrunrange"), "", wingspec.getAttackRunRange());}
                if (wingspec.getAttackPositionOffset() != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "attackpositionoffset"), "", wingspec.getAttackPositionOffset());}
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "fluxcapacity"), "", hullspec.getFluxCapacity());
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "fluxdissipation"), "", hullspec.getFluxDissipation());
                if (hullspec.getShieldSpec() != null) {
                    if (hullspec.isPhase() && ShieldType.PHASE.equals(hullspec.getShieldType())) {
                        SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "phasecost"), "", hullspec.getShieldSpec().getPhaseCost());
                        SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "phaseupkeep"), "", hullspec.getShieldSpec().getPhaseUpkeep());
                    }
                    if (ShieldType.FRONT.equals(hullspec.getShieldType()) || ShieldType.OMNI.equals(hullspec.getShieldType())) {
                        SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "shieldarc"), "", hullspec.getShieldSpec().getArc());
                        SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "shieldefficiency"), "", hullspec.getShieldSpec().getFluxPerDamageAbsorbed());
                        SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "shieldupkeep"), "", hullspec.getShieldSpec().getUpkeepCost());
                    }
                }
                tooltip.addTable("", 0, opad);
            } else if (presses2 == 0 && hullspec == null) {tooltip.addPara(Global.getSettings().getString("timid_tmi", "emptybay"), opad);}
            if (presses2 == 1) {
                boolean wow = false;
                tooltip.setBulletedListMode("• ");
                tooltip.addSectionHeading(Global.getSettings().getString("timid_tmi", "wingtags"), Alignment.MID, opad);
                if (!wingspec.getTags().isEmpty()) {
                    for (String tag: wingspec.getTags()) {
                        SoTrueBestie(tooltip, tag);
                    }
                    wow = true;
                }
                if (hullspec != null && !hullspec.getTags().isEmpty()) {
                    for (String tag: hullspec.getTags()) {
                        SoTrueBestie(tooltip, tag);
                    }
                    wow = true;
                }
                if (hullspec != null && !hullspec.getHints().isEmpty()) {
                    for (ShipHullSpecAPI.ShipTypeHints hint : hullspec.getHints()) {
                        SoTrueBestie(tooltip, hint.toString());
                    }
                    wow = true;
                }
                if (!wow) {tooltip.addPara(Global.getSettings().getString("timid_tmi", "sotruebestie"), opad);}
                tooltip.setBulletedListMode(null);
            }
            if (presses2 >= 2 && presses2-2 < wingspec.getVariant().getFittedWeaponSlots().size() && hullspec != null) {
                WeaponSlotAPI slot = (WeaponSlotAPI) wingspec.getVariant().getSlot((String) new ArrayList<String>(wingspec.getVariant().getFittedWeaponSlots()).get(presses2-2));
                WeaponSpecAPI weaponspec = wingspec.getVariant().getWeaponSpec((String) new ArrayList<String>(wingspec.getVariant().getFittedWeaponSlots()).get(presses2-2));
                tooltip.addSectionHeading(hullspec.getHullName()+" - "+weaponspec.getWeaponName(), Alignment.MID, opad);
                tooltip.beginTable(Misc.getBasePlayerColor(), Misc.getDarkPlayerColor(), Misc.getBrightPlayerColor(), 15f, Global.getSettings().getString("timid_tmi", "stat"), 220f, Global.getSettings().getString("timid_tmi", "value"), 130f);
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "angle"), "", slot.getAngle());
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "arc"), "", slot.getArc());
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "range"), "", weaponspec.getMaxRange());
                if (!weaponspec.isBeam() && weaponspec.getProjectileSpec() != null && weaponspec.getProjectileSpec() instanceof ProjectileSpecAPI) {
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "minspread"), "", weaponspec.getMinSpread());
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "maxspread"), "", weaponspec.getMaxSpread());
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "spreadshot"), "", weaponspec.getSpreadBuildup());
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "spreaddecaysec"), "", weaponspec.getSpreadDecayRate());
                } else if (!weaponspec.isBeam() && weaponspec.getProjectileSpec() != null && weaponspec.getProjectileSpec() instanceof MissileSpecAPI) {
                    if (weaponspec.getMaxSpread() > 0 && weaponspec.getSpreadBuildup() > 0 && weaponspec.getSpreadDecayRate() > 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "minspread"), "", weaponspec.getMinSpread());
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "maxspread"), "", weaponspec.getMaxSpread());
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "spreadshot"), "", weaponspec.getSpreadBuildup());
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "spreaddecaysec"), "", weaponspec.getSpreadDecayRate());}
                    if (((MissileSpecAPI) weaponspec.getProjectileSpec()) != null) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "missilespeed"), "", ((MissileSpecAPI) weaponspec.getProjectileSpec()).getLaunchSpeed());}
                    if (((MissileSpecAPI) weaponspec.getProjectileSpec()).getHullSpec() != null && ((MissileSpecAPI) weaponspec.getProjectileSpec()).getHullSpec().getHitpoints() > 0) SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "missilehitpoints"), "", ((MissileSpecAPI) weaponspec.getProjectileSpec()).getHullSpec().getHitpoints());
                    if (((MissileSpecAPI) (weaponspec.getProjectileSpec())).getArmingTime() > 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "armingtime"), "", ((MissileSpecAPI) (weaponspec.getProjectileSpec())).getArmingTime());}
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "maxflighttime"), "", ((MissileSpecAPI) (weaponspec.getProjectileSpec())).getMaxFlightTime());
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "explosionradius"), "", ((MissileSpecAPI) (weaponspec.getProjectileSpec())).getExplosionRadius());
                    if (((MissileSpecAPI) (weaponspec.getProjectileSpec())).getHullSpec().getEngineSpec() != null) {
                        EngineSpecAPI enginespec = ((MissileSpecAPI) (weaponspec.getProjectileSpec())).getHullSpec().getEngineSpec();
                        SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "missiletopspeed"), "", enginespec.getMaxSpeed());
                        SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "missileacceleration"), "", enginespec.getAcceleration());
                        SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "missiledeceleration"), "", enginespec.getDeceleration());
                        SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "missileturnrate"), "", enginespec.getMaxTurnRate());
                        SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "missileturnacceleration"), "", enginespec.getTurnAcceleration());
                    }
                } else if (weaponspec.isBeam() && weaponspec.getProjectileSpec() != null && weaponspec.getProjectileSpec() instanceof BeamAPI) {
                    if (weaponspec.getMaxSpread() > 0 && weaponspec.getSpreadBuildup() > 0 && weaponspec.getSpreadDecayRate() > 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "minspread"), "", weaponspec.getMinSpread());
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "maxspread"), "", weaponspec.getMaxSpread());
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "spreadshot"), "", weaponspec.getSpreadBuildup());
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "spreaddecaysec"), "", weaponspec.getSpreadDecayRate());}
                }
                tooltip.addTable("", 0, opad);
            }
            
        }
        tooltip.addPara(Global.getSettings().getString("timid_tmi", "F1F2F3Please")+presses2, Misc.getGrayColor(), opad);
    }
    
    private void SoTrueBestie(TooltipMakerAPI tooltip, String string) {
        if (!Global.getSettings().getString("timid_tmi", string).equals(String.format(Global.getSettings().getString("timid_tmi", "tmi_debug"), string))) {String text = Global.getSettings().getString("timid_tmi", string);tooltip.addPara(String.format("%s: %s", string, text), 2f, Misc.getHighlightColor(), string);}
        else {tooltip.addPara(String.format("%s", string), 2f, Misc.getHighlightColor(), string);}
    }
    
    private Object SoTrueBestie(TooltipMakerAPI tooltip, String string, String string2, float float1) {
            Color[] colors = new Color[2];
            colors[0] = Misc.getTextColor();
            colors[1] = Misc.getHighlightColor();
            String text1 = Misc.getRoundedValue(float1)+string2;
            return tooltip.addRow(Alignment.LMID, colors[0], string, Alignment.RMID, colors[1], text1);
        }
    
    private Object SoTrueBestie(TooltipMakerAPI tooltip, String string, float float1, float float2, boolean truefalse) {
        return SoTrueBestie(tooltip, string, "", float1, float2, truefalse);
    }
    
    private Object SoTrueBestie(TooltipMakerAPI tooltip, String string, String string2, float float1, float float2, boolean truefalse) {
        Color[] colors = new Color[3];
        colors[0] = Misc.getTextColor();
        colors[1] = Misc.getHighlightColor();
        colors[2] = truefalse ? float1 > float2 ?  Misc.getPositiveHighlightColor() : Misc.getNegativeHighlightColor() : float1 < float2 ?  Misc.getPositiveHighlightColor() : Misc.getNegativeHighlightColor();
        String text1 = Misc.getRoundedValue(float1)+string2;
        String text2 = (float1 != float2 ? float1 > float2 ? "(+"+Misc.getRoundedValue(float1-float2)+string2+")" : "("+Misc.getRoundedValue(float1-float2)+string2+")" : float1 < float2 ? "("+Misc.getRoundedValue(float1-float2)+string2+")" : "");
        return tooltip.addRow(Alignment.LMID, colors[0], string, Alignment.RMID, colors[1], text1, Alignment.LMID, colors[2], text2);
    }
    
	@Override
	public boolean shouldAddDescriptionToTooltip(HullSize hullSize, ShipAPI ship, boolean isForModSpec) {
		return true;
	}
    
    @Override
	public String getDescriptionParam(int index, HullSize hullSize) {
		return null;
	}

	@Override
	public boolean isApplicableToShip(ShipAPI ship) {
		return true;
	}
	
        @Override
	public String getUnapplicableReason(ShipAPI ship) {
		return null;
	}
}
