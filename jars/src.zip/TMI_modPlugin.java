package data.hullmods;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;

public class TMI_modPlugin extends BaseModPlugin {
    @Override
    public void afterGameSave() {
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_ships");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_wings");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_weapons");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_beams");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_missiles");
    }

    @Override
    public void beforeGameSave() {
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_ships");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_wings");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_weapons");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_beams");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_missiles");
    }
    
}
